﻿using System.Collections.Generic;

namespace Desafio.Negocios
{
    internal class ArrayList<T> : List<Dia>
    {
    }
}