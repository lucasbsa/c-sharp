﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio.Negocios
{
    class DistribuicaoDePalestrantes
    {

        public static bool districuiPalestrante(Dia dia) {
            return false;
        }

    }
}
